from matplotlib import pyplot

pyplot.plot([0, 2, 4, 8, 16, 32], "o-")

pyplot.ylabel("Value")
pyplot.xlabel("Time")
pyplot.title("Test plot")

pyplot.show()
